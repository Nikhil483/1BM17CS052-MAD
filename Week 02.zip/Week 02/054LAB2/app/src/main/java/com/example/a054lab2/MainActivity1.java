package com.example.a054lab2;

interface MainActivity1 {
}
